Step 1 siapkan 2 hp

1 sebagai hotspot

Atur nama hotspot : 

Nama hotspot : home3
Password : 123ya123


Setting dlu ke hotspot sekali agar tersimpan di unie nya dari laptop/pc ke hotspot itu kika tyda ada laptop/pc lewati ini
Langsung pisang usb unyl ke casan dia akan kopek ke hp 1 nnt automatis



2 HP ke due download app ini
https://www.mediafire.com/file/wrmg4sqsfunsnxu/appsetusb.apk/file
Hubungkan HP ke 2 ke hotspot hp 1
Tancep USB UNYL Ke hp ke 2

Buka APK
Setting WIFI dll

Tau download putty app



Putty PC/Laptop : https://putty.org/index.html

https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html

https://www.mediafire.com/file/s8vm6xgpnhz5mdx/putty.zip/file


Putty Android : 

https://play.google.com/store/apps/details?id=mobileSSH.feng.gao

https://play.google.com/store/apps/details?id=com.server.auditor.ssh.client

https://play.google.com/store/apps/details?id=com.tower.ssh.client

Tutor Wifi ony
https://www.mediafire.com/file/0p2f9krzgkbwa23/tutor-unyl.zip/file


LINK TUTOR SETTING LEWAT HP : 
https://www.mediafire.com/file/d7v6bqmwu3ntjun/tutor_set_lewat_hp.zip/file

TUTOR DOCKER UNYL
https://www.mediafire.com/file/w35f35np6pqne0n/tutor_docker_unyl.txt/file

TUTOR DOCKER TRAFFICMONIZE :
https://www.mediafire.com/file/gs32or67us609je/github_tm.docx/file

TUTOR PROBLEM TRAFFICMONIZE : 
https://www.mediafire.com/file/awgy72dc07db7te/problem_tm.docx/file

TUTOR REMOTE SEMUA DEVICE UNYL :
https://www.mediafire.com/file/6r9yokw5l9wrzmh/ssh.zip/file
Gtihub : https://github.com/BlackDragon100IDN/sshremoteall/tree/main

CEK IP KWALITAS
https://www.facebook.com/share/p/1DE7rjxZXD/

TUTOR MENIGKATKAN PROFIT UNYL METODE 1 :
Github : https://github.com/BlackDragon100IDN/tenangyakan001/blob/main/README.md
DOCX : https://www.mediafire.com/file/7eqh8vlkqocpfqs/episode1_cuk_1.docx/file

TUTOR BOT TELE V2.2 rev1:
https://www.mediafire.com/file/v2p72fyuu6y8myw/install_bot.docx/file
Github : https://github.com/BlackDragon100IDN/telegrambotnyil
Youtube : https://www.youtube.com/watch?v=Jp3uDGUMDO0

